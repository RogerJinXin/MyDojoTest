#!/bin/sh

java -jar ../shrinksafe/js.jar ../../dojo/dojo.js baseUrl=../../dojo load=doh "$@"